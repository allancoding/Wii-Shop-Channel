//
//  shopping channel
//

shop = new wiiShop ;

//  shop.title          : Localized strings of "Wii Shop Channel"
//  shop.menuBtn        : Localized strings of "Wii Menu"
//  shop.retryBtn       : Localized strings of "Try Again"
//  shop.returnToMenu() : Return to Wii Menu
//  shop.getLogUrl      : The variable is set to the log-get-URL.
//  shop.beginWaiting() : Begin to display the waiting icon.
//  shop.endWaiting()   : End to display the waiting icon.

//  shop.setWallpaper( wallpaper )  : change the wallpaper on given arg.
var cWP_Dots  = 0 ; // default
var cWP_Black = 1 ;
var cWP_White = 2 ;
var cWP_VLine = 3 ;

//  shop.enableHRP()
//  shop.disableHRP()   : Enable/disable HBM,reset,power-off

//  shop.connecting     : The connecting message strings.
